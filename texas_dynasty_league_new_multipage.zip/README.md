# Texas Dynasty League Website
Multi-page static website. Upload all files in this folder to the root of your GitHub repository.
Pages:
- index.html
- divisions.html
- schedule.html
- top-players.html
- standings.html
- styles.css
- league-logo.svg
