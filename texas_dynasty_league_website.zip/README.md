# Texas Dynasty League Website

A free, mobile-friendly single-page website for the Texas Dynasty League.

## Put it online for free
1. Create a GitHub account if you don't already have one.
2. Create a new public repository named `texas-dynasty-league`.
3. Upload `index.html`.
4. In Settings → Pages, choose Deploy from branch → main → root.
5. GitHub will provide the live website address.

The site is intentionally simple to edit: team names, rankings, records, schedule weeks, and history are stored directly in `index.html`.
